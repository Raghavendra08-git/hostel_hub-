document.addEventListener('DOMContentLoaded', function () {
    console.log('HostelHub App Loaded');

    // --- Chart.js Logic for Admin Dashboard ---
    const ctx = document.getElementById('complaintChart');
    if (ctx) {
        fetch('/api/stats')
            .then(response => response.json())
            .then(data => {
                const categories = Object.keys(data.categories);
                const counts = Object.values(data.categories);

                new Chart(ctx, {
                    type: 'bar', // Changed to BAR for better clarity
                    data: {
                        labels: categories,
                        datasets: [{
                            label: 'Complaints by Category',
                            data: counts,
                            backgroundColor: [
                                '#3b82f6', '#06b6d4', '#8b5cf6', '#ec4899', '#f59e0b'
                            ],
                            borderWidth: 0,
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#64748b' } },
                            x: { grid: { display: false }, ticks: { color: '#64748b' } }
                        },
                        plugins: {
                            legend: { display: false }
                        }
                    }
                });
            })
            .catch(err => console.error('Error loading stats:', err));
    }
});

// --- Chatbot Logic ---
function toggleChat() {
    console.log('Toggling Chat...');
    const chatWindow = document.getElementById('chatWindow');
    chatWindow.classList.toggle('show');
}

function handleEnter(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if (!msg) return;

    // Add User Message
    addMessage(msg, 'user');
    input.value = '';

    // Simulate thinking/network
    const chatBody = document.getElementById('chatBody');
    chatBody.scrollTop = chatBody.scrollHeight;

    // Send to API
    fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg })
    })
        .then(res => res.json())
        .then(data => {
            addMessage(data.response, 'bot');
        })
        .catch(err => {
            console.error(err);
            addMessage("Sorry, I'm having trouble retrieving that info.", 'bot');
        });
}

function addMessage(text, sender) {
    const chatBody = document.getElementById('chatBody');
    const div = document.createElement('div');
    div.classList.add('chat-msg');
    div.classList.add(sender === 'user' ? 'chat-user-msg' : 'chat-bot-msg');
    div.innerHTML = text; // Allow basic HTML
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;
}
